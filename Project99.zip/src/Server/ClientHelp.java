package Server;

import Client.Command;
import Client.Profile;
import Whatever.Time;

import java.util.HashMap;
import java.util.Map;
public class ClientHelp {
    public static Map<String,Object> signUp(Map<String,Object> income){
        Profile newProfile = (Profile) income.get("profile");
        String username = newProfile.getUsername();
        Server.users.put(username,newProfile);
       // DBManager.getInstance().updateDataBase(); // save to local file
        Map<String,Object> ans = new HashMap<>();
        ans.put("command",Command.SignUp);
        ans.put("answer",true);
        System.out.println(newProfile.getUsername() + " register" /* + TODO */); //add image address
        System.out.println("time : "+Time.getTime());
        System.out.println(newProfile.getUsername() + " signin");
        System.out.println("time : "+Time.getTime());
        return ans;
    }
    /**
     login api in server side
     it give username and passwrod from income map and check if the username Exists
     if the username doesnt exists it return null profile with the exists boolean : false
     if the username exists, the exists boolean is true
     then it use profile.authenticate to make sure that the username and password match ( authenticate could be changed later for improve security)
     if the username and Password math, we return profile (which is used as token)
     otherwise we return null as profile
     **/
    public static Map<String,Object> login(Map<String,Object> income){

        String username = (String) income.get("username");
        String password = (String) income.get("password");

        Boolean isNullProfile = (Server.users.get(username) == null);
        Map<String,Object> ans = new HashMap<>();
        ans.put("command",Command.Login);
        ans.put("exists",!isNullProfile);
        if(isNullProfile){
            return ans;
        }
        Profile profile = Server.users.get(username).authenticate(username, password);
        ans.put("answer",profile);

        if(profile != null){
            System.out.println(profile.getUsername() + " signin");
            System.out.println("time : "+ Time.getTime());
        }
        return ans;
    }
}
