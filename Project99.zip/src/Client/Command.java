package Client;

public enum Command {
    Login,
    SignUp,
    ForgotPassword,
    Username_unique,
    Publish_Post,
    LoadTimeLine
}
