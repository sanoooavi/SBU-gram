package Client;

import java.util.HashMap;
import java.util.Map;

public class ServerHelp {
    public static Boolean signUp(Profile profile){
        Map<String,Object> toSend = new HashMap<>();
        toSend.put("command", Command.SignUp);
        toSend.put("profile", profile);
        Map<String,Object> received = Network.serve(toSend);
        if ( received.get("answer") == null ) return null;
        return (Boolean) received.get("answer");
    }
    public static Profile login(String username, String password){
        Map<String,Object> toSend = new HashMap<>();
        toSend.put("command",Command.Login);
        toSend.put("username",username);
        toSend.put("password",password);
        Map<String,Object> received = Network.serve(toSend);
        if (received.get("answer") == null ) return null;
        return (Profile)received.get("answer");
    }
    public static boolean isUserNameExists(String text) {
        return false;
    }
}
