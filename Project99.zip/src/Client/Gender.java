package Client;

public enum Gender {
    Male,Female,Non_Binary,Not_Say
}
